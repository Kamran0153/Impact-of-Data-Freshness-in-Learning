import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow import keras
import argparse

path = "datarobot.csv"
df = pd.read_csv(path)

feature_keys = [
    "D0",
    "D1",
    "D2",
    "D3",
    "D4",
    "D5",
    "D6",
    "D7",
    "D8",
    "D9",
    "D10",
    "D11",
    "D12",
    "D13",
    "D14",
    "D15",
    "D16",
    "D17",
    "D18",
    "D19"
]

split_fraction = 0.8
train_split = int(split_fraction * int(df.shape[0]))
step = 1
learning_rate = 0.001
batch_size = 32
epochs = 20
Exppoints=25
Age=np.arange(Exppoints)*2
score=np.zeros(len(Age))
score1=np.zeros(len(Age))

#including Past u data in feature vectors for u Order Markov Approximation
parser = argparse.ArgumentParser()
parser.add_argument('--u', type=int, required=True, help='Size of the feature')
args=parser.parse_args()

u=args.u #size of the feature
print('size of the feature', u)

seed=[111, 123, 130, 240, 260, 45, 23, 46, 27, 45]
for m in range(1):
    
    for i in range(len(Age)):
        
        print(Age[i])
        future=Age[i]
        #past=1
        selected_features = [feature_keys[i] for i in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]]
        features = df[selected_features]
        features = pd.DataFrame(features.values)
  
  
        train_data = features.loc[0 : train_split - 1]
        val_data = features.loc[train_split:]    
        start = future
        end = start + train_split

        x_train = train_data[[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]].values
        l=len(x_train)
        xt=x_train[0:l-u,:]
        x_trainu=[]
        for j in range(l-u):
            y=xt[j]
            for k in range(u-1):
                y=np.append(y, x_train[j+k+1])
            x_trainu.append(y.tolist())
        x_trainu=np.array(x_trainu)
  
        y_train = features.iloc[start:end-u][[10, 11, 12, 13, 14, 15, 16, 17, 18, 19]]
  
        x_end = len(val_data) - future

        label_start = train_split + future

        x_val = val_data.iloc[:x_end][[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]].values
        lv=len(x_val)
        xt=x_val[0:lv-u,:]
        x_valu=[]
        for j in range(lv-u):
            y=x_val[j]
            for k in range(u-1):
                y=np.append(y, x_val[j+k+1])
            x_valu.append(y.tolist())
        x_valu=np.array(x_valu)
        y_val = features.iloc[label_start:label_start+lv-u][[10, 11, 12, 13, 14, 15, 16, 17, 18, 19]]
    
        tf.random.set_seed(seed[m])
        input=10*u
        model= tf.keras.Sequential([
            tf.keras.layers.Dense(input, activation='relu'),
            tf.keras.layers.Dense(256, activation='relu'),
            tf.keras.layers.Dense(10)
        ])
        model.compile(optimizer='sgd',
                 loss=tf.keras.losses.MeanSquaredError(),
                 metrics=['mse'])
        history=model.fit(x_trainu, y_train, batch_size=batch_size, epochs=epochs)
        score[i]=score[i]+(model.evaluate(x_trainu, y_train)[0]-score[i])/(m+1)
        score1[i]=score1[i]+(model.evaluate(x_valu, y_val)[0]-score1[i])/(m+1)

        np.save('TrainingErrorRobotic.npy',score)
        np.save('InferenceErrorRobotic.npy',score1)